<?php include"connect.php";
session_start();
if(isset($_REQUEST['status']))
	{
		echo "<script>alert('Appication Submitted Succesfully');</script>";
	}
	if(isset($_SESSION['user']))
	{
		echo "<style>#login{display:none;}</style>";
		echo "<style>#logout{display:block;}</style>";
		echo "<style>#status{display:none;}</style>";
		echo "<style>#status2{display:block;}</style>";
	}
	else{
		echo "<style>#logout{display:none;}</style>";
		echo "<style>#status2{display:none;}</style>";
	}
?>

<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MargParivahan Online Driving Licence System</title>
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="js/freelancer.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link href="css/freelancer.min.css" rel="stylesheet">
<link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">