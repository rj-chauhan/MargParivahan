<?php
include '../../connect.php';
mysql_select_db('2989');
require('fpdf.php');
$pdf=new FPDF('P','mm','A4');
$sql = "select * from licence where appno='".$_REQUEST['applicationNum']."' and dob='".$_REQUEST['dateOfBirth']."'";
$retval = mysql_query( $sql, $link );
$row = mysql_fetch_assoc($retval); 
if($row['images']!='' and $row['adhar']!=''){
$pdf->AddPage();
$pdf->SetFont('Arial','B',18);

$pdf->Cell(50,10,"Hello Dear  \"".$row['name']."\", Your Appointment Letter.",0,0);
$pdf->Cell(50,10,"",0,1);


$pdf->Cell(50,10,'Name',0,0);
$pdf->Cell(60,10,$row['name'],0,1);

$pdf->Cell(50,10,'Father Name',0,0);
$pdf->Cell(60,10,$row['father'],0,1);

$pdf->image("../../".$row['images'],150,30,50,35);


$pdf->Cell(50,10,'Pincode',0,0);
$pdf->Cell(60,10,$row['pincode'],0,1);

$pdf->Cell(50,10,'Gender',0,0);
$pdf->Cell(60,10,$row['gender'],0,1);

$pdf->Cell(50,10,'Blood',0,0);
$pdf->Cell(60,10,$row['blood'],0,1);

$pdf->Cell(50,10,'Email',0,0);
$pdf->Cell(60,10,$row['email'],0,1);

$pdf->Cell(50,10,'State',0,0);
$pdf->Cell(60,10,$row['state'],0,1);

$pdf->Cell(50,10,'RTO',0,0);
$pdf->Cell(60,10,$row['rto'],0,1);

$pdf->Cell(50,10,'Date Of Birth',0,0);
$pdf->Cell(60,10,$row['dob'],0,1);

$pdf->Cell(50,10,'Adhar Card No',0,0);
$pdf->Cell(60,10,$row['aadhar'],0,1);

$pdf->Cell(50,10,'Education',0,0);
$pdf->Cell(60,10,$row['edu'],0,1);

$pdf->Cell(50,10,'Phone no',0,0);
$pdf->Cell(60,10,$row['phone'],0,1);

$pdf->Cell(50,10,'Address',0,0);
$pdf->Cell(60,10,$row['address'],0,1);

$pdf->Cell(60,10,'',0,0);
$pdf->Cell(60,10,"",0,1);

$pdf->Cell(60,10,'',0,0);
$pdf->Cell(60,10,"",0,1);

$pdf->Cell(60,10,'',0,0);
$pdf->Cell(60,10,"",0,1);

$pdf->Cell(60,10,'',0,0);
$pdf->Cell(60,10,"",0,1);

$pdf->Cell(60,10,'',0,0);
$pdf->Cell(60,10,"",0,1);



$pdf->Cell(60,10,'Your Appointment Date is '.$row['slot_date'].'',0,0);
$pdf->Cell(60,10,'',0,1);

$pdf->AddPage();
$pdf->image("../../".$row['adhar'],10,20,180,300);

$pdf->output();				
}
else
{
	header('location: ../../download.php?id=1');
}
?>