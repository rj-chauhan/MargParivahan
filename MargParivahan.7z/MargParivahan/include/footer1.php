<footer class="text-center">     
        <div class="footer-below">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        Copyright &copy; Blackhat Tech.
                    </div>
                </div>
            </div>
        </div>
    </footer>
