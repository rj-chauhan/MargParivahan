<?php
	include "connect.php";
	if(isset($_REQUEST['app']))
	{
		$sql = "select * from licence where appno='".$_REQUEST['app']."' and slot_date='no' and dob='".$_REQUEST['dob']."'";
		   mysql_select_db('2989');
		   $retval = mysql_query( $sql, $link );         
		   while($row = mysql_fetch_assoc($retval)) 
		   {?>
			<div class="col-md-6">
				<h4 class="text-center">Application Details</h4>
				<div class="col-md-3" >
					<img src="img/user.png"></img>
				</div>&nbsp;&nbsp;
				Name : <font style="color:green"><?php echo $row['name'];?> </font><br>&nbsp;&nbsp;
				Application Number : <font style="color:green"><?php echo $row['appno'];?> </font><br>&nbsp;&nbsp;
				RTO Office : <font style="color:green"><?php echo $row['rto'];?> </font><br>&nbsp;&nbsp;
				Date Of Birth : <font style="color:green"><?php echo $row['dob'];?></font><br>&nbsp;&nbsp;
				
				Phone Number : <font style="color:green"><?php echo $row['phone'];?> </font>
			</div>
			
		  <?php 
		  }
	}
	else
	{
		echo "Sorry";
	}
?>