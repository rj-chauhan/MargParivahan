<?php
	include "connect.php";
	$sql = "select * from account where user='".$_REQUEST['user']."' and pass='".$_REQUEST['pass']."'";
	mysql_select_db('2989');
	$retval=mysql_query($sql,$link);
	$row = mysql_fetch_assoc($retval);
	if($row['user']==$_REQUEST['user'] and $row['pass']==$_REQUEST['pass'])
	{
		session_start();
		$_SESSION["user"] = $row['user'];		
		header("Location:index.php");
	}	
	else
	{
		echo "1";
	}
?>