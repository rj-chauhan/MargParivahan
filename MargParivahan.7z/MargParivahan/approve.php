<?php
	include "connect.php";
	$sql = "update licence set status='Complete' where appno='".$_REQUEST['app']."'";
	mysql_select_db('2989');
	$retval = mysql_query( $sql, $link );
	if(! $retval ) {
		   die('Could not update data: ' . mysql_error());
		}
		echo "Approved";
?>