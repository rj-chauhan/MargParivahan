<!DOCTYPE html>
<html lang="en">
<head>
    <?php include "include/head.php";
	
	?>
	<script>
	$(document).ready(function(){
		$('#cancleform').submit(function(){
			app = $('#canapp').val();
			$.ajax({
				type : 'POST',
				data : {app:app},
				url : 'cancle.php',
				success :function(response){
					alert("Slot Cancellation complete..")
				}
			});
			return false;
		});
		$('#check').submit(function(){
			app = $('#appid').val();
			dob = $('#dob').val();
			$.ajax({
				type:'POST',
				data : {app:app,dob:dob},
				url : 'status_check.php',
				success :function(response){
					alert(response);
				}
			});
			return false;
		});
		$("#applynow").click(function(){
			$("#typeli").modal("show");			
		});
		$("#next").click(function(){
			$("#typeli").modal("hide");			
			$("#open").modal("show");			
		});
		$('#dl').click(function(){
			if($(".llnumber").prop('disabled') == false)
			{
				$('.llnumber').prop("disabled", true);
				$('.lldate').prop("disabled", true);
			}
			$('.dlnumber').prop("disabled", false);
			$('.dldate').prop("disabled", false);
		});
		$('#ll').click(function(){
			if($(".dlnumber").prop('disabled') == false)
			{
				$('.dlnumber').prop("disabled", true);
				$('.dldate').prop("disabled", true);
			}
			$('.llnumber').prop("disabled", false);
			$('.lldate').prop("disabled", false);
		});
		$('#nothing').click(function(){
			$('.dlnumber').prop("disabled", true);
			$('.dldate').prop("disabled", true);
			$('.llnumber').prop("disabled", true);
			$('.lldate').prop("disabled", true);
		});
	});
	</script>
</head>
<body id="page-top" class="index">
    <!-- Navigation -->
		<?php include "include/nav.php"; ?>
			<?php include "status.php"; ?>
			<?php include "login-modal.php";?>
    <!-- Header -->
    <header id="home" style="height:700px;">
        <div class="container" id="maincontent" tabindex="-1">
            <div class="row">
				<div class="col-md-6">
					
					<img src="img/profile.png"/>
					<h1>MARG PARIVAHAN</h1>
				</div>
								<div class="col-md-6">
<h3>Welcome to Ministry of Road Transport & Highways</h3>
<p>
The Ministry of Road Transport & Highways has been facilitating computerization of more than 1000 Road Transport Offices (RTOs) across the country. RTOs issue Registration Certificate (RC) & Driving License (DL) that are valid across the country. It was necessary to define same standards for these documents on a pan-India level to ensure interoperability and correctness and timely availability of information.It was necessary to define same standards for these documents on a pan-India level to ensure interoperability and correctness and timely availability of information.  </p>
				</p>
				</div>

            </div>
        </div>
    </header>
    <section id="portfolio">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>Services</h2>
                    <hr class="star-primary">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 portfolio-item" id="apply">
                    <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
								<p>Apply Now For Driving Licence</p>
                                <button onclick="document.getElementById('id01').style.display='block'" class="btn btn-warning" id="applynow">Apply Now</button>
                            </div>
                        </div>
                        <img src="img/register.png" style="height:200px !important;margin-top:30px;margin-left:70px;" class="img-responsive" alt="register">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal2" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
								<p>Upload Documents</p>
								<button class="btn btn-warning" onclick="location.href = 'upload.php';">Upload &nbsp;<span class="fa fa-upload"></span></button>
                            </div>
                        </div>
                        <img src="img/upload.png" style="height:200px !important;margin-top:30px;margin-left:70px;" class="img-responsive" alt="register">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal3" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <p>Appointments (Slot Booking)</p>
								<button class="btn btn-warning" onclick="location.href = 'slotbook.php';">Book Now &nbsp;<span class="fa fa-sign-in"></span></button>
                            </div>
                        </div>
                        <img src="img/schedule.png" style="height:200px !important;margin-top:30px;margin-left:70px;" class="img-responsive" alt="register">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal4" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <p>Cancle Appoinments</p>
								<button data-toggle="modal" data-target="#cancle" class="btn btn-warning" >Cancle Now.. <span class="fa fa-times"></span></button>
                            </div>
                        </div>
                        <img src="img/calendar-cancel.png" style="height:200px !important;margin-top:30px;margin-left:70px;" class="img-responsive" alt="register">
                    </a>
                </div>
                <div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal5" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <p>Licence Details</p>
								<button class="btn btn-warning" onclick="location.href = 'licenceDetails.php';" >Check Details <span class="fa fa-sign-in"></span></button>
                            </div>
                        </div>
                        <img src="img/3.png" style="height:200px !important;margin-top:30px;margin-left:20px;" class="img-responsive" alt="Details">
                    </a>
                </div>
                
				<div class="col-sm-4 portfolio-item">
                    <a href="#portfolioModal6" class="portfolio-link" data-toggle="modal">
                        <div class="caption">
                            <div class="caption-content">
                                <p>Download Filled-In Forms</p>
								<button class="btn btn-warning" onclick="location.href = 'download.php';" >Download <span class="fa fa-download"></span></button>
                            </div>
                        </div>
                        <img src="img/download.png" style="height:200px !important;margin-top:30px;margin-left:70px;" class="img-responsive" alt="Print">
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="success" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2>About</h2>
                    <hr class="star-light">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-lg-offset-2">
                    <p>Marg Parivahan is website where you can apply for driving licence,check yoour existing application status,booking slot,and even you can cancle you appoinment.</p>
                </div>
                <div class="col-lg-4">
                    <p>Marg Parivahan is working since 2017 and and company has best reputation on market.The CEO Mr.Gaurav says that Marg Parivahan is Another SarthiService of RTO.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include "include/footer.php";?>
    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-top page-scroll hidden-sm hidden-xs hidden-lg hidden-md">
        <a class="btn btn-primary" href="#page-top">
            <i class="fa fa-chevron-up"></i>
        </a>
    </div>

	<!--All Modal Of Services -->
	<div id="cancle" class="modal fade" role="dialog">
<div class="modal-dialog">

<!-- Modal content-->
<div class="modal-content" style="width:400px;margin-left:100px;">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title">cancle Appoinment</h4>
</div>
<form id="cancleform" class="form-inline">
<div class="modal-body">
Application Number  <p style="color:red;display:inline;">*</p> :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" class="form-control" id="canapp" style="display:inline !important;" required><br><br>
Date of Birth  <p style="color:red;display:inline;">*</p> :<input type="date" id="dob" class="form-control"style="margin-left:60px;"required><br><br>
<input type="submit" class="btn btn-success" style="margin-left:90px;">&nbsp;&nbsp;&nbsp;&nbsp;
<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
</form>
</div>
</div>

</div>
</div>
	<div id="id01" class="w3-modal">
 <div class="w3-modal-content w3-card-4 w3-animate-zoom">
  <header class="w3-container w3-blue"> 
   <span onclick="document.getElementById('id01').style.display='none'" 
   class="w3-button w3-blue w3-xlarge w3-display-topright">&times;</span>
   <h2>Apply Online</h2>
  </header>

  <div class="w3-bar w3-border-bottom">
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'London')">Apply For ?</button>
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Paris')">Details</button>
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Tokyo')">Licence Number</button>
  </div>

  <div id="London" class="w3-container city" >
   <h1>Apply for what ??</h1>
   <select id="select" class="form-control" style="width:250px;display:inline-block;" >
		<option hidden>select option</option>
		<option>New Leaner's Licence</option>
		<option>New Driving Licence</option>		
	  </select> &nbsp;&nbsp;&nbsp;
	  <button onclick="document.getElementsByClassName('tablink')[1].click();" style="display:inline-block;" type="button" class="btn btn-success" id="next" >Next Step...</button><br><br>
  </div>

  <div id="Paris" class="w3-container city" style="display:none;">
   <p>Following are the stages in Application Submission in Issuing Learner's Licence in the following order</p>
   <ol>
	<li>Fill Applicant Details</li>
	<li>Upload Documents</li>
	<li>Upload Photo and Signature</li>
	<li>LL Test Slot Booking</li>
	<li>Payment of Fee</li>
   </ol>
   <button class="btn btn-success" onclick="document.getElementsByClassName('tablink')[2].click();">Process..</button><br><br>
  </div>

  <div id="Tokyo" class="w3-container city" style="display:none;">
   <p>Select appropriate choice</p><br>
   <div>
	Select appropriate choice<br>
	<input type="radio" name="choice" id="nothing" checked> I don't have any Licence  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="radio" name="choice" id="dl" />Holding Driving Licence, Enter DL Number &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<input type="radio" name="choice" id="ll"> Holding Learner's Licence, Enter LL Number &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br><br>
	<input type="text" class="form-control dlnumber" style="display:inline-block;width:250px;" placeholder="Enter Driving Licence Number" disabled>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date Of Birth
	<input type="date" class="form-control dldate" style="display:inline-block;width:200px;" disabled>
	<br><br>
		<input type="text" class="form-control llnumber" style="display:inline-block;width:250px;" placeholder="Enter Driving Licence Number" disabled>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date Of Birth
	<input type="date" class="form-control lldate" style="display:inline-block;width:200px;" disabled><br>
	<br><a href="form.php"><button type="submit" class="btn btn-success" style="margin-left:10px;">Fiil The Form&nbsp;&nbsp;&nbsp;&nbsp;
	</button></a><br><br>
</div>
  </div>

  <div class="w3-container w3-light-grey w3-padding">
   <button class="w3-btn w3-right w3-white w3-border" 
   onclick="document.getElementById('id01').style.display='none'">Close</button>
  </div>
 </div>
</div>
<script>
document.getElementsByClassName("tablink")[0].click();

function openCity(evt, cityName) {
	if($('#select').val()=="select option")
	{
		document.getElementsByClassName("tablink")[0].click();
	}
	else
	{
	  var i, x, tablinks;
	  x = document.getElementsByClassName("city");
	  for (i = 0; i < x.length; i++) {
		x[i].style.display = "none";
	  }
	  tablinks = document.getElementsByClassName("tablink");
	  for (i = 0; i < x.length; i++) {
		tablinks[i].classList.remove("w3-light-grey");
	  }
	  document.getElementById(cityName).style.display = "block";
	  evt.currentTarget.classList.add("w3-light-grey");
	}
}
$(document).ready(function(){
  // Add smooth scrolling to all links
  $("#mainNav a").on('click', function(event) {
	
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
});

</script>

</body>

</html>
