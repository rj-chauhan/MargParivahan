<?php
	include "connect.php";
	if(isset($_REQUEST['app']))
	{
		
		$sql = "update licence set slot_date='".$_REQUEST['date']."',status='Slot has been Book' where appno='".$_REQUEST['app']."'";
		echo $sql;
		mysql_select_db('2989');
		$retval = mysql_query( $sql, $link );
		if(! $retval ) {
               die('Could not update data: ' . mysql_error());
            }
            echo "<style>#disp{display:none;}</style>";
	}
	else
	{
		echo "Sorry";
	}
?>