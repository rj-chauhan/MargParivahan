<?php 
		include "connect.php";
		$state = $_REQUEST['state'];
		$RTO = $_REQUEST['RTO'];
		$pin = $_REQUEST['pincode'];
		$fname = $_REQUEST['fname'];
		$mname = $_REQUEST['mname'];
		$lname = $_REQUEST['lname'];
		$ffname = $_REQUEST['ffname'];
		$fmname = $_REQUEST['fmname'];
		$flname = $_REQUEST['flname'];
		$aadhar = $_REQUEST['aadhar'];
		$gender = $_REQUEST['gender'];
		$dob = $_REQUEST['dob'];
		$age = $_REQUEST['age'];
		$edu = $_REQUEST['edu'];
		$blood = $_REQUEST['blood'];
		$phone = $_REQUEST['phone'];
		$email = $_REQUEST['email'];
		$addstate = $_REQUEST['addstate'];
		$district = $_REQUEST['district'];
		$town = $_REQUEST['town'];
		$add1 = $_REQUEST['add1'];
		$add2 = $_REQUEST['add2'];
		$add3 = $_REQUEST['add3'];
		$addr = array($_REQUEST['addstate'],$_REQUEST['district'],$_REQUEST['town'],$_REQUEST['add1'],$_REQUEST['add2'],$_REQUEST['add3']);
		$name = array($fname,$mname,$lname);
		$fname = array($ffname,$fmname,$flname);
		$sql = "insert into licence (`state`, `rto`, `pincode`, `name`, `father`, `aadhar`, `gender`, `dob`, `age`, `edu`, `blood`, `phone`, `email`, `address`) values ('".$state."','".$RTO."','".$pin."','".implode(" ",$name)."','".implode(" ",$fname)."','".$aadhar."','".$gender."','".$dob."',".$age.",'".$edu."','".$blood."','".$phone."','".$email."','".implode(" ",$addr)."')";
		   mysql_select_db('2989');
		   $retval = mysql_query( $sql, $link );         
           if(! $retval ) {
               die('Could not enter data: ' . mysql_error());
            }
            header('Location: index.php?status=ok');
?>