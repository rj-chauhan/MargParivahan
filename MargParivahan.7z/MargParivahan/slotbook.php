<?php include "include/head.php";?>
<?php include "include/nav.php";?>
<?php include "status.php"; ?>
<script>
	$(document).ready(function(){
		$('#confirm').click(function(){
			app = $('#application').val();
			date = $('#date').val();
			if (confirm("Are you sure to Book Slot on Selected Date!") == true) {

			$.ajax({
				type : 'POST',
				data : {app:app,date:date},
				url : 'book_slot.php',
				success :function(response){
					$("#disp").css("display", "none");
					$('#date').val(null);
					alert(response);
				}
			});
			} else {
				alert("Try Again....");
			}
			return false;
		});
		$('#form').submit(function(){
			var app = $('#application').val();
			var dob = $('#dateOfBirth').val();
			$.ajax({
				type : 'POST',
				data : {app:app,dob:dob},
				url : 'Getapplication.php',
				success : function(response){
					$('#disp').html(response);
				}
			})
			return false;
		});
	});
</script>
	<?php include "login-modal.php";?>
	<div id="ok"></div>
				<div class="col-md-12" style="margin-top:110px;">
				<h3 class="text-center">Slot Booking</h3><br>
					<div class="row">							
						<div class="col-md-12">
						<form id="form">
								<div class="row">
									<div
										class="col-md-2  col-md-offset-1  text-right">
										<label >*Application Number</label>
									</div>
									<div class="col-md-2">
										<input type="text" class="form-control imput-sm" id="application" placeholder="Enter Application Number" required/>
									</div>
									<div class="col-md-2 text-right">
										<label>*Date of Birth</label>
									</div>
									<div class="col-md-2">
										<input type="date" size="10" id="dateOfBirth" class="form-control input-sm" required/>
									</div>
									<div class="col-md-2 text-center">
										<input type="submit" value="Submit"  id="submitbtn" class="btn btn-sm btn-success"/>
										<a href="index.php#portfolio"><input type="button" value="Cancel" id="cancelbtn"  class="btn btn-sm btn-danger"/></a>
									</div></div>
								</form>
							</div>							
					</div>
				</div>
				<div class="container" style="margin-top:250px;" disabled>
					<div id="disp">
					</div>
					<div class="col-md-6">
						<h5 class="text-center">Select the Day you want to book slot</h5> <br>
						Selected Date :&nbsp; <input type="date" style="display:inline-block;width:250px;" class="form-control" id="date">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-success" id="confirm">Confirm</button><br>
					</div>
				</div><br><br>
				<p style="margin-left:20px;"><span class="fa fa-check"></span> Enter your Application Number And Date Of Birth to Download Your  Application</p>
<?php include "include/footer1.php";?>