<?php
		include "connect.php";
		include "include/head.php";
		include "include/nav.php";
		$sql = "select * from licence where images !=''";
		$retval = mysql_query($sql,$link);
?>
<script>
	$(document).ready(function(){
		$('.btn-success').click(function(){
			var app = $(this).attr("id");
			$.ajax({
				type :'post',
				data : {app:app},
				url : 'approve.php',
				success :function(response){
					alert(response);
				}
			});
			return false;
		});
	});
</script>
<div class="container" style="margin-top:150px;">
	<table class="table">
    <thead>
      <tr>
		<th style="width:200px;">Application No</th>
        <th>Name</th>
        <th>phone</th>
        <th style="width:400px;">Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = mysql_fetch_assoc($retval)){?>
		<tr>
			<td><?php echo $row['appno'];?></td>
			<td><?php echo $row['name'];?></td>
			<td><?php echo $row['phone'];?></td>
			<td><?php echo $row['email'];?></td>
			<td><button class="btn btn-success" id="<?php echo $row['appno'];?>">Approve</button></td>
		</tr>
		<?php } ?>
    </tbody>
  </table>
</div>