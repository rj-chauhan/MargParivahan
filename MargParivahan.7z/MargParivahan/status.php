<div id="app" class="modal fade" role="dialog">
<div class="modal-dialog">
<div class="modal-content" style="width:400px;margin-left:100px;">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title">Application Status</h4>
</div>
<form id="check" class="form-inline">
<div class="modal-body">
Application Number  <p style="color:red;display:inline;">*</p> :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type="text"id="appid" class="form-control"style="display:inline !important;"><br><br>
Date of Birth  <p style="color:red;display:inline;">*</p> :<input type="date" id="dob" class="form-control"style="margin-left:60px;"><br><br>
<input type="submit" class="btn btn-success" style="margin-left:90px;">&nbsp;&nbsp;&nbsp;&nbsp;
<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
</form>
</div>
</div>

</div>
</div>