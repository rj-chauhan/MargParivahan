<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
	      <!-- Modal content-->
      <div class="modal-content" style="width:400px;margin-left:135px;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Enter Your Login Details...</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="login_check.php" class="form-inline">
			Enter Your UserName :&nbsp;&nbsp;&nbsp;<input type="text" name="user" class="form-control" required/><br><br>
			Enter Your Password :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="pass" class="form-control" required/><br><br>
			<center><input type="submit" class="btn btn-success" Value="Login Now"></center>
		  </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>