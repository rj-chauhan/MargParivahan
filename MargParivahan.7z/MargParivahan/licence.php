<?php
	include "connect.php";
	$sql = "select * from licence where appno='".$_REQUEST['app']."' and dob='".$_REQUEST['dob']."'";
   mysql_select_db('2989');
   $retval = mysql_query( $sql, $link );         
   $row = mysql_fetch_assoc($retval);
?>
<form method="get" action="form_submit.php">
				<div class="col-md-12">
					<fieldset class="col-md-12 col-xs-12 "><br><br	>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label>*Name of the Applicant</label>
							</div>
							<div class="col-md-3">
								<input type="text" id="fname" value="<?php echo $row['name'];?>" class="form-control" style="text-transform: uppercase;" disabled>
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3">
								<div class="row">
									<div class="col-md-6 control-label  ">
										<label class="red">*</label>
										<label>Father's Name</label>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<input type="text" name="ffname" value="<?php echo $row['father'];?>" class=" form-control" style="text-transform: uppercase;" disabled>
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label>Aadhaar Number</label>
							</div>
							<div class="col-md-2">
								<input type="text" value="<?php echo $row['aadhar'];?>" class="form-control" style="text-transform: uppercase;" disabled>
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label class="red">*</label>
								<label>Gender</label>
							</div>
							<div class="col-md-3 left control-label">
								<input type="text" class="form-control" value="<?php echo $row['gender'];?>" disabled>
							</div>
							<div class="col-md-2 control-label">
								<label>*Date of Birth</label>
							</div>
							<div class="col-md-2">
								<input type="date" class="  form-control" value="<?php echo $row['dob'];?>" style="text-transform: uppercase;" disabled>
							</div>
							<div class="col-md-2">
								<div class="row">
									<div class="col-md-1 control-label">
										<label>Age</label>
									</div>
									<div class="col-md-6">
										<input type="text" class="form-control" value="<?php echo $row['age'];?>" style="text-transform: uppercase;" disabled>
									</div>
									<div class="col-md-1 control-label">
										<label>Yrs</label>
									</div>
								</div>
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-2 control-label ">
								<label>Phone Number</label>
							</div>
							<div class="col-md-3">
								<div class="row">
									<div class="col-md-4">
										<input type="text" name="phone" value="+91" disabled="disabled" class="  form-control center" style="text-transform: uppercase;" disabled>
									</div>
									<div class="col-md-8">
										<input type="text" maxlength="10" value="<?php echo $row['phone'];?>" class="  form-control" style="text-transform: uppercase;" disabled>
									</div>
								</div>
							</div>
						
							<div class="col-md-1"></div>
							<div class="col-md-2 control-label ">
								<label>Email Id</label>
							</div>
							<div class="col-md-3">
								<input type="text" value="<?php echo $row['email'];?>" maxlength="254" class="  form-control" disabled>
							</div>
						</div><br>
						<br>
					</fieldset>
				</div><br>
		</form>