<html>
<head>
<?php include "include/head.php";?>
</head>
<script>
	$(document).ready(function(){
		$('#licenceFromRTO').prop('disabled', true);
		$('#licenceFromState').change(function(){
			$('#licenceFromRTO').prop('disabled', false);
		});
		$('#Date').change(function(){
			var dob = $('#Date').val();
			if(dob != ''){
				var str=dob.split('-');    
				var firstdate=new Date(str[0],str[1],str[2]);
				var today = new Date();        
				var dayDiff = Math.ceil(today.getTime() - firstdate.getTime()) / (1000 * 60 * 60 * 24 * 365);
				var age = parseInt(dayDiff);
				$('#age').val(age);
				if(age<18)
				{
					$("#target :input").prop("disabled", true);
					$("#Date").prop("disabled", false);
					$("#age").prop("disabled", false);
				}
				else{
					$("#target :input").prop("disabled", false);
				}
			}
		});
	});
</script>
<body>
<?php include "include/nav.php"; ?>
	<?php include "status.php"; ?>
	<?php include "login-modal.php";?>
<div class="jumbotron" style="margin-top:100px;">
<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title">
				<label>Application for Learner's Licence (LL)</label>
			</h3>
		</div>
		<div class="panel-body">
			<form method="get" id="target" action="form_submit.php">
				<div class="col-md-12 padding0px">
					<label>Select State and RTO office from where LL is being applied</label>
				</div>

				<div class="col-md-12">
					<div class="col-md-1 control-label  ">
						<label>*State</label>
					</div>
					<div class="col-md-2">
						<select name="state" class="form-control">
    <option value="Null">Select</option>
    <option value="gujarat">Gujarat</option>
    </select>
					</div>
					<div class="col-md-2 control-label">
						<label>*RTO Office</label>
					</div>
					<div class="col-md-3">
						<select  name="RTO"  class="  form-control">
    <option value="-1">Select</option>
    <option value="rajkot">RTO,RAJKOT--GJ03</option>
</select>
					</div>
					<div class="col-md-1 control-label">
						<label>Pincode</label>
					</div>
					<div class="col-md-2">
						<input type="text" name="pincode" maxlength="6" value="" id="pincode" class="form-control" title="PinCode" oncopy="return false;" onpaste="return false;" placeholder="Pincode">
					</div>
				</div>
				<div class="col-md-12">
					<fieldset class="col-md-12 col-xs-12 ">
						<legend>
							<label class="black">Personal Details</label>
						</legend>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label>*Name of the Applicant</label>
							</div>
							<div class="col-md-3">
								<input type="text" id="fname" name="fname" class="form-control" oncopy="return false;" onpaste="return false;" placeholder="First Name" style="text-transform: uppercase;">
							</div>
							<div class="col-md-2">
								<input type="text" name="mname" id="mname" class=" form-control" oncopy="return false;" onpaste="return false;" placeholder="Middle Name" style="text-transform: uppercase;">
							</div>
							<div class="col-md-3">
								<input type="text" name="lname" class=" form-control" oncopy="return false;" onpaste="return false;" placeholder="Last Name" style="text-transform: uppercase;">
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3">
								<div class="row">
									<div class="col-md-6 control-label  ">
										<label class="red">*</label>
										<label>Father's Name</label>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<input type="text" name="ffname" class=" form-control" oncopy="return false;" onpaste="return false;" placeholder="First Name" style="text-transform: uppercase;">
							</div>
							<div class="col-md-2">
								<input type="text" name="fmname" class="form-control" oncopy="return false;" onpaste="return false;" placeholder="Middle Name" style="text-transform: uppercase;">
							</div>
							<div class="col-md-3">
								<input type="text" name="flname"class="form-control" oncopy="return false;" onpaste="return false;" placeholder="Last Name" style="text-transform: uppercase;">
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label>Aadhaar Number</label>
							</div>
							<div class="col-md-2">
								<input type="text" id="Aadhaar" name="aadhar" maxlength="12" class="  form-control"oncopy="return false;" onpaste="return false;" placeholder="Aadhaar Number" style="text-transform: uppercase;">
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label class="red">*</label>
								<label>Gender</label>
							</div>
							<div class="col-md-3 left control-label">
									<input type="radio" name="gender" value="1">
								<label for="gender1" class=" ">Male </label>
									<input type="radio" name="gender" id="gender2" value="2" >
								<label for="gender2" class=" ">Female      </label>
									<input type="radio" name="gender" id="gender3" value="3">
								<label for="gender3" class=" ">Trans Gender</label>

							</div>
							<div class="col-md-2 control-label">
								<label>*Date of Birth</label>
							</div>
							<div class="col-md-2">
								<input type="text" id="Date" name="dob" class="  form-control" oncopy="return false;" onpaste="return false;" placeholder="YYYY-MM-DD" style="text-transform: uppercase;">
							</div>
							<div class="col-md-2">
								<div class="row">
									<div class="col-md-1 control-label">
										<label>Age</label>
									</div>
									<div class="col-md-6">
										<input type="text" id="age" name="age" class="  form-control"  oncopy="return false;" onpaste="return false;" style="text-transform: uppercase;">
									</div>
									<div class="col-md-1 control-label">
										<label>Yrs</label>
									</div>
								</div>
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-3 control-label">
								<label>*Qualification</label>
							</div>
							<div class="col-md-2">
								<select name="edu" id="eduQual" class="  form-control">
									<option value="-1">Select</option>
									<option value="2"> 8th Passed</option>
									<option value="5">10+2 or Equivalent</option>
									<option value="3">10th Standard or Equivalent</option>
									<option value="1">Below 8th</option>
									<option value="6">Diploma in any Discipline</option>
									<option value="13">Doctrate  in any Discipline</option>
									<option value="8">Graduate in Non Medical Sciences</option>
									<option value="7">Graduate in any Medical Sciences</option>
									<option value="4">ITI/Certificate Course</option>
									<option value="0">Illiterate</option>
									<option value="12">M.Phil. in any Discipline</option>
									<option value="999">Not Specified / NA</option>
									<option value="10">Post Graduate Diploma in any Discipline</option>
									<option value="9">Post Graduate in Non Medical Sciences</option>
									<option value="11">Post Graduate in any Medical Science</option>
								</select>
							</div>
							<div class="col-md-1"></div>
							<div class="col-md-2 control-label  ">
								<label>Blood Group</label>
							</div>
							<div class="col-md-2">
								<select name="blood" id="bloodGroup" class="  form-control">
									<option value="A+ ">A+        </option>
									<option value="A- ">A-        </option>
									<option value="AB+">AB+       </option>
									<option value="AB-">AB-       </option>
									<option value="B+ ">B+        </option>
									<option value="B- ">B-        </option>
									<option value="O+ ">O+        </option>
									<option value="O- ">O-        </option>
									<option value="U  ">Unknown   </option>
								</select>
							</div>
						</div><br>
						<div class="row padding-top">
							<div class="col-md-2 control-label ">
								<label>Phone Number</label>
							</div>
							<div class="col-md-3">
								<div class="row">
									<div class="col-md-4">
										<input type="text" name="phone" value="+91" disabled="disabled" class="  form-control center" style="text-transform: uppercase;">
									</div>
									<div class="col-md-8">
										<input type="text" name="phone" maxlength="10" value="" id="mobileNumber" class="  form-control" oncopy="return false;" onpaste="return false;" placeholder="Mobile Number" style="text-transform: uppercase;">
									</div>
								</div>
							</div>
						
							<div class="col-md-1"></div>
							<div class="col-md-2 control-label ">
								<label>Email Id</label>
							</div>
							<div class="col-md-3">
								<input type="text" id="email" name="email" maxlength="254" value="" id="email" class="  form-control" oncopy="return false;" onpaste="return false;" placeholder="Ex:abc@xyz.com">
							</div>
						</div><br>
						<br>
					</fieldset>
				</div>
				<div class="col-md-12 ">
					<fieldset class="col-md-12 col-xs-12 left">
						<legend >
							<label>Address</label>
						</legend>
						<div class="row">
							<font style="margin-left:80px">State</font> 
								<select class="form-control" name="addstate" style="width:200px;display:inline;">
									<option value="gujarat">Gujarat</option>
								</select>
							<font style="margin-left:80px">District</font> 
								<select class="form-control" name="district" style="width:200px;display:inline;">
									<option value="rajkot">Rajkot</option>
								</select>
							<font style="margin-left:80px">Village/Town</font> 
								<select class="form-control" name="town" style="width:200px;display:inline;">
									<option value="rajkot">Rajkot</option>
								</select><br><br>
							<font style="margin-left:80px">Address 
								<input type="text" name="add1" class="form-control" style="width:200px;display:inline; margin-left:20;">
								<input type="text" name="add2" class="form-control" style="width:200px;display:inline; margin-left:20;">
								<input type="text" name="add3" class="form-control" style="width:200px;display:inline; margin-left:20;">
							<font style="margin-left:40px">Pincode</font><input type="text" class="form-control" style="width:200px;display:inline; margin-left:20px;">
							<br>
						</div>

					</fieldset>
				</div>
			
				<div class="col-md-12 padding0px">
					<fieldset class="scheduler-border col-md-12 col-xs-12 left">
						<legend class="scheduler-border fieldsetLable-newll">
							<label class="black">Declaration</label>
						</legend>
						<div class="col-md-12 padding0px">
							<div class="col-md-9 left">
								<label>1. </label>
								<label>I am willing to donate my organs, in case of accidental death?</label>
								<input type="checkbox" name="willingToDonate" value="true" id="willlingToDonate" class="checkbox-inline"><input type="hidden" id="__checkbox_willlingToDonate" name="__checkbox_willingToDonate" value="true">
								<label>(Please Tick if willing)</label>
							</div>
						</div>

						<div class="col-md-12 padding0px">
							<div class="col-md-9 left">
								<label>2.</label>
								<label>I here by declare that to the best of my knowledge and belief the particulars given above are true</label>
								<label>YES</label>
								<input type="checkbox" name="accepted" value="true" id="accepted" class="checkbox-inline" onclick="checkDeclaration(this);" checked="true"><input type="hidden" id="__checkbox_accepted" name="__checkbox_accepted" value="true">
								<label>NO</label>
								<input type="checkbox" name="notAccepted" value="true" id="notAccepted" class="checkbox-inline" onclick="checkDeclaration(this);"><input type="hidden" id="__checkbox_notAccepted" name="__checkbox_notAccepted" value="true">
							</div>
						</div></fieldset></div><br>
					<div class="col-md-12"><br>
						<div class="col-md-2">
							<div >
								<small><label>*Indicates Mandatory</label></small>
							</div>
						</div>
						<div class="col-md-9 text-center">
								<input type="submit" value="Submit" id="submitButton" class="btn btn-success"> &nbsp;&nbsp;
							<input type="reset" value="Refresh"  class="btn btn-warning" >&nbsp;&nbsp;
								<a href="index.php"><button  class="btn btn-danger">Cancle</button></a>
					</div>
		</div>
		</form>
	</div>
</div>
</div>
<?php include "include/footer1.php";?>
</body>
</html>