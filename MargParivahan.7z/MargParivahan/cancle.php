<?php
	include "connect.php";
	if(isset($_REQUEST['app']))
	{
		
		$sql = "update licence set slot_date='no' where appno='".$_REQUEST['app']."'";
		mysql_select_db('2989');
		$retval = mysql_query( $sql, $link );
		if(!$retval) {
               die('Could not update data: ' . mysql_error());
            }
		echo "Slot Booking Cancellation has been successful...";
	}
	else
	{
		echo "Sorry";
	}
?>