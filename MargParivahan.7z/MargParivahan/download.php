<?php include "include/head.php";?>
<?php include "include/nav.php";?>
<?php include "status.php"; ?>
<?php include "login-modal.php"; if(isset($_REQUEST['id'])){echo "<script>alert('No Data Found');</script>";}?>
	
<div class="panel panel-primary" style="margin-top:130px;height:250px;">
			<div class="panel-heading" style="text-align: left">
				<h3 class="panel-title">
					<label>Ener Licence Details To Download</label>
				</h3>
			</div>
			<div class="panel-body" style="margin-top:50px;">
				<div class="col-md-12">
					<div class="row">
						<form method="post" action="include/fpdf/licencePDF.php" target="_blank">							
						<div class="col-md-12">
								<div class="row">
									<div
										class="col-md-2  col-md-offset-1  text-right">
										<label >*Application Number</label>
									</div>
									<div class="col-md-2">
										<input type="text" name="applicationNum" maxlength="9" value="" id="applicationNum" class="form-control input-sm" placeHolder="Enter ApplicationNumber" required/>
									</div>
									<div class="col-md-2 text-right">
										<label>*Date of Birth</label>
									</div>
									<div class="col-md-2">
										<input type="date" name="dateOfBirth" size="10" maxlength="10" value="" id="dateOfBirth" class="form-control input-sm" required/>
									</div>
									<div class="col-md-2 text-center">
										<input type="submit" value="Get PDF" id="submitbtn" class="btn btn-sm btn-success"/>										
									</div></div>
							</div>							
						</form>
						<div class="row">
							<div class="col-md-12  control-label" align="left">
								<span class="bold red"><small>* indicates Mandatory</small></span>
							</div>
						</div>
					</div>
				</div><br><br><br><br>
				<p style="margin-left:20px;"><span class="fa fa-check"></span> Enter your Application Number And Date Of Birth to Download Your  Application</p>
			</div>
		</div>
<?php include "include/footer1.php";?>