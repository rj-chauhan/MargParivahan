<?php
	include "connect.php";
	mysql_select_db('2989');
	$sql = "select * from licence where appno='".$_REQUEST['applicationNum']."' and slot_date='no' and dob='".$_REQUEST['dateOfBirth']."'";		   
	$retval = mysql_query( $sql, $link );         
	$all = mysql_fetch_assoc($retval);
	
	if(isset($_REQUEST['applicationNum'])){
	$sql = "select * from licence where appno='".$_REQUEST['applicationNum']."'  and dob='".$_REQUEST['dateOfBirth']."'";
		   
		   $retval = mysql_query( $sql, $link );         
		   if($row = mysql_fetch_assoc($retval)){
				echo "ok";
		   }
		else
		{
			echo "not";
		}
	}
	if($all['status'] != "no")
		if(isset($_FILES['file']))
		{
			extract($_REQUEST);
			$target_dir = "uploads/";
			$target_file = $target_dir.basename($_FILES["file"]["name"]);
			$name = explode(".",$_FILES["file"]["name"]);
			$ext = $name[1];		
			if(move_uploaded_file($_FILES["file"]["tmp_name"], $target_file))
			{
			rename($target_file,"uploads/".$_REQUEST['appno']."0.".$ext);
			$target_file = "uploads/".$_REQUEST['appno']."0.".$ext;
			//echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
			if($upload = mysql_query("update licence set images='".$target_file."' where appno=".$_REQUEST['appno'] , $link))
			{
				echo "ok<br>";
				echo $target_file;
				header("location: upload.php");
				
			}
			else{
				echo "not";
			}		
			
			} else {
				echo "Sorry, there was an error uploading your file Please try again";
			}
		}
		if(isset($_FILES['adhar']))
		{
			extract($_REQUEST);
			$target_diru = "uploads/";
			$target_fileu = $target_diru.basename($_FILES["adhar"]["name"]);
			$nameu = explode(".",$_FILES["adhar"]["name"]);
			$extu = $nameu[1];		
			if(move_uploaded_file($_FILES["adhar"]["tmp_name"], $target_fileu))
			{
			rename($target_fileu,"uploads/".$_REQUEST['appno']."1.".$extu);
			$target_fileu = "uploads/".$_REQUEST['appno']."1.".$ext;
			//echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
			if($upload = mysql_query("update licence set adhar='".$target_fileu."' where appno=".$_REQUEST['appno'] , $link))
			{
				echo "ok<br>";
				echo $target_fileu;
				header("location: upload.php");
				
			}
			else{
				echo "not";
			}		
			
			} else {
				echo "Sorry, there was an error uploading your file Please try again";
			}
		}
?>