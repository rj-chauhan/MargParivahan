<?php include "include/head.php";?>
<?php include "include/nav.php";?>
<?php include "status.php"; ?>
	<?php include "login-modal.php";?>
<script>
	$(document).ready(function(){
		$('#details').submit(function(){
			app = $('#appids').val();
			dob = $('#doba').val();
			$.ajax({
				type : 'POST',
				data : {app:app,dob:dob},
				url : 'licence.php',
				success :function(response){
					$('#display').html(response);
				}
			});
			return false;
		});
	});
</script>
<div class="panel panel-primary" style="margin-top:130px;height:600px;">
			<div class="panel-heading" style="text-align: left">
				<h3 class="panel-title">
					<label>Licence Details</label>
				</h3>
			</div>
			<div class="panel-body" style="margin-top:50px;">
				<div class="col-md-12">
					<div class="row">
						<form id="details">							
						<div class="col-md-12">
								<div class="row">
									<div
										class="col-md-2  col-md-offset-1  text-right">
										<label >*Application Number</label>
									</div>
									<div class="col-md-2">
										<input type="text" id="appids" maxlength="9" class="form-control input-sm" placeHolder="Enter ApplicationNumber"/>
									</div>
									<div class="col-md-2 text-right">
										<label>*Date of Birth</label>
									</div>
									<div class="col-md-2">
										<input type="date" size="10" maxlength="10" id="doba" class="form-control input-sm"/>
									</div>
									<div class="col-md-2 text-center">
										<input type="submit" value="Submit" id="submitbtn" class="btn btn-sm btn-success"/>
										<input type="reset" value="Cancel" id="cancelbtn"  class="btn btn-sm btn-danger"/>
									</div></div>
							</div>							
						</form>
						<div class="row"><br><br>
							<div class="col-md-12  control-label" id="display">
								
							</div>
						</div>
					</div>
				</div>
				<br><br><br><br>
			</div>
		</div>
<?php include "include/footer1.php";?>