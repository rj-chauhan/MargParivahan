-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 19, 2017 at 06:11 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `2989`
--
CREATE DATABASE IF NOT EXISTS `2989` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `2989`;

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` varchar(15) NOT NULL,
  `name` varchar(20) NOT NULL,
  `user` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `name`, `user`, `pass`, `phone`) VALUES
('1', 'Admin', 'Admin', 'admin', '9999999999');

-- --------------------------------------------------------

--
-- Table structure for table `licence`
--

CREATE TABLE IF NOT EXISTS `licence` (
  `state` varchar(20) NOT NULL,
  `rto` varchar(20) NOT NULL,
  `pincode` int(6) NOT NULL,
  `name` varchar(60) NOT NULL,
  `father` varchar(60) NOT NULL,
  `aadhar` int(14) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `age` int(3) NOT NULL,
  `edu` varchar(15) NOT NULL,
  `blood` varchar(5) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(25) NOT NULL,
  `address` varchar(80) NOT NULL,
  `appno` int(10) NOT NULL AUTO_INCREMENT,
  `slot_date` varchar(10) NOT NULL DEFAULT 'no',
  `status` varchar(20) NOT NULL DEFAULT 'no',
  `images` varchar(100) NOT NULL,
  `adhar` varchar(100) NOT NULL,
  PRIMARY KEY (`appno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `licence`
--

INSERT INTO `licence` (`state`, `rto`, `pincode`, `name`, `father`, `aadhar`, `gender`, `dob`, `age`, `edu`, `blood`, `phone`, `email`, `address`, `appno`, `slot_date`, `status`, `images`, `adhar`) VALUES
('gujarat', 'rajkot', 360001, 'asb jsbcjb jbcdcb', 'jsdbsdb jbcdj jbcjc', 11515, '1', '2017-09-18', 20, '4', 'A+ ', '9537376220', 'abc@gmail.com', 'gujarat rajkot rajkot rajkot tako ssoeppsok', 1, '2017-09-18', 'Slot has been Book', '', ''),
('gujarat', 'rajkot', 360006, 'Rohit chauhan j', 'j k c', 2147483647, '1', '1992-02-11', 20, '6', 'A+ ', '7600370060', 'abc@gmail.com', 'gujarat rajkot rajkot jamnagar Road Rajkot sanjaynagar-1', 2, '2017-09-05', 'Slot has been Book', '', ''),
('gujarat', 'rajkot', 360006, 'ramiz theba r', 'rr r rr', 11515, '1', '1998-07-17', 19, '8', 'A+ ', '7600370060', 'rsnv@gmail.com', 'gujarat rajkot rajkot rajkot rajkot rajkot', 3, '2017-09-20', 'Complete', 'uploads/30.jpg', 'uploads/31.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
