<?php include "include/head.php";?>
<?php include "include/nav.php";?>
<?php include "status.php"; ?>
<?php include "login-modal.php";?>
<script>
$(document).ready(function(){
	$("#uploadForm").submit(function(){
	applicationNum = $("#applicationNum").val();
	dateOfBirth  = $("#dateOfBirth").val();
	//alert(dateOfBirth);
	
			 $.ajax({
				type : 'POST',
				data : {applicationNum:applicationNum,dateOfBirth:dateOfBirth},
				url : 'check_upload.php',
				success :function(response){					
					if(response == "ok")
					{
						$(".change").html("<form action='check_upload.php' enctype='multipart/form-data'method='post' id='upload' ><h2>Upload Document</h2> your photo <input type='file' class='form-control' accept='image/*' name='file' id='fileChooser'>your adhar card<input type='file' class='form-control' accept='image/*' name='adhar' id='Chooser'><input type='hidden' name='appno' value="+applicationNum+"><input type='submit' value='upload' name='upload'></form>");
					}
					else
					{
						$(".change").html(response);
					}
				}
			});
			return false;
	});
});
</script>
<div class="panel panel-primary" style="margin-top:130px;height:380px;">
			<div class="panel-heading" style="text-align: left">
				<h3 class="panel-title">
					<label>Upload Documents</label>
				</h3>
			</div>
			<div class="panel-body" style="margin-top:20px;">
				<div class="col-md-12">
					<div class="row">
						<form id="uploadForm" name="uploadForm" method="post" >							
						<div class="col-md-12">
								<div class="row">
									<div
										class="col-md-2  col-md-offset-1  text-right">
										<label >*Application Number</label>
									</div>
									<div class="col-md-2">
										<input type="text" maxlength="9" value="" id="applicationNum" class="form-control input-sm" placeHolder="Enter ApplicationNumber"/>
									</div>
									<div class="col-md-2 text-right">
										<label>*Date of Birth</label>
									</div>
									<div class="col-md-2">
										<input type="date" size="10" maxlength="10" value="" id="dateOfBirth" class="form-control input-sm"/>
									</div>
									<div class="col-md-2 text-center">
										<input type="submit" value="Submit" id="submitbtn" class="btn btn-sm btn-success"/>
										
									</div></div>
							</div>							
						</form>
						<div class="row">
							<div class="col-md-12  control-label" align="left">
								<span class="bold red"><small>* indicates Mandatory</small></span>
							</div>
						</div>
					</div>
				</div>
					<div class="col-md-12 change" style="margin-top:20px;">
						<div class="col-md-4">
							<img src="img/upload-1.png" style="height:200px;margin-left:80px;" classs="img-responsive"></img>
						</div>
						<div class="col-md-8" >
							<p>Following Document Will Needed while uploading document</p>
							<div class="col-md-4">
							<b><p>Accepted age proofs</p></b>
							<ol>
								<li>10th class mark sheet</li>
								<li>PAN Card</li>
								<li>Birth Certificate</li>
							</ol>
							</div>
							<div class="col-md-4">
							<b><p>Address proofs</p></b>
							<ol>
								<li>Aadhar Card</li>
								<li>Own house Electric Bill</li>
								<li>Passport</li>
								<li> Ration Card</li>
								<li> Voter Id</li>
							</ol>
							</div>
							<div class="col-md-4" >
							<b><p>Photographs</p></b>
							<ol>
								<li>6 Passport size photographs during LL</li>
								<li>1 Passport size photograph during DL</li>
							</ol>
							</div>
						</div>
					</div>
			</div>
		</div>
<?php include "include/footer1.php";?>