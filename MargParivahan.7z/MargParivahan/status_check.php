<?php
	include "connect.php";
	$sql = "select * from licence where appno='".$_REQUEST['app']."' and dob='".$_REQUEST['dob']."'";
	mysql_select_db("2989");
	$retval = mysql_query($sql,$link);
	$row = mysql_fetch_assoc($retval);
	echo $row['status']
?>